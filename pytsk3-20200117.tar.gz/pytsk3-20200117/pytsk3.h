/*
** pytsk3.h
** 
** Made by mic
** Login   <mic@laptop>
** 
** Started on  Sat Apr 17 20:48:58 2010 mic
** Last update Sat Apr 17 20:48:58 2010 mic

this is a shadow file: Do not directly include it - we redefine some
of TSK specific structs so we can bind them here.
*/

#ifndef   	PYTSK3_H_
# define   	PYTSK3_H_

#include <tsk3/libtsk.h>
#include "class.h"


#endif 	    /* !PYTSK3_H_ */
